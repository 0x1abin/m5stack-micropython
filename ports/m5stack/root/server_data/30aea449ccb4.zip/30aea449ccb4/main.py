import m5

#m5.fillRect(0, 0, 100, 100, 0x0074A0)
m5.fill(0x0074A0)
#m5.fill(0xff00ff)